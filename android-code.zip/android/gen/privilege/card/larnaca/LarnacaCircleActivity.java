package privilege.card.larnaca;

import org.appcelerator.titanium.TiRootActivity;

public final class LarnacaCircleActivity extends TiRootActivity
{
}
